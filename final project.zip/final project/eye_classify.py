import os
import cv2
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, Input


dataset_dir = "C:/Users/vani1/OneDrive/Desktop/eoc 2/archive/train"
open_eye_dir = "C:/Users/vani1/OneDrive/Desktop/eoc 2/archive/train/Open"  
closed_eye_dir = "C:/Users/vani1/OneDrive/Desktop/eoc 2/archive/train/Closed"  

#  Image size for CNN
IMG_SIZE = 64  

#  Lists to store images and labels
images = []
labels = []

#  Read images and assign labels based on folder name
for category, folder in [("open", open_eye_dir), ("closed", closed_eye_dir)]:
    label = 1 if category == "open" else 0  # Open = 1, Closed = 0
    
    if not os.path.exists(folder):
        print(f" Error: Folder '{folder}' not found!")
        continue
    
    for filename in os.listdir(folder):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            image_path = os.path.join(folder, filename)
            image = cv2.imread(image_path)
            image = cv2.resize(image, (IMG_SIZE, IMG_SIZE))  # Resize to CNN input size
            image = image / 255.0  # Normalize (0 to 1)
            images.append(image)
            labels.append(label)

#  Convert to NumPy arrays
X = np.array(images)
y = np.array(labels)

#  One-hot encode labels (for categorical classification)
y = to_categorical(y, num_classes=2)  

#  Train-test split
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
print(f" Loaded {len(X_train)} training images and {len(X_val)} validation images.")

#  CNN model
model = Sequential([
    Input(shape=(64, 64, 3)),
    Conv2D(32, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(2, activation='softmax')
])

#  Compile Model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()

#  Train the model
history = model.fit(
    X_train, y_train, 
    epochs=20, 
    batch_size=32, 
    validation_data=(X_val, y_val)
)

#  Save the trained model
model.save('eye_classification_model.keras')
print(" CNN Model Trained and Saved Successfully!")

#  Evaluate Model
loss, acc = model.evaluate(X_val, y_val)
print(f" Validation Accuracy: {acc:.2f}")

#  Load and Test the Model
def predict_eye(image_path):
    image = cv2.imread(image_path)
    if image is None:
        print(f" Error: Could not read image {image_path}")
        return
    
    image = cv2.resize(image, (64, 64))
    image = image / 255.0  # Normalize
    image = np.expand_dims(image, axis=0).astype(np.float32)  # Ensure correct format

    model = tf.keras.models.load_model("eye_classification_model.keras")
    prediction = model.predict(image)[0]
    
    print(f"🔹 Model Raw Output: {prediction}")  # Debugging
    
    if np.argmax(prediction) == 1:
        print(" Detected: Open Eye")
    else:
        print(" Detected: Closed Eye")

#  Test with an image
predict_eye("C:/Users/vani1/OneDrive/Desktop/eoc 2/archive/train/Closed/_3.jpg")
#  Plot Training & Validation Accuracy
plt.figure(figsize=(12, 5))

# Accuracy Plot
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.title('Training & Validation Accuracy')
plt.legend()

# Loss Plot
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training & Validation Loss')
plt.legend()

# Show plots
plt.show()