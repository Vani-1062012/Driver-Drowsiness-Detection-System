import os
import cv2


datasets = {
    "yawn": {
        "images": "C:/Users/vani1/OneDrive/Desktop/eoc 2/yolo mouth detection/yawn train/images",
        "labels": "C:/Users/vani1/OneDrive/Desktop/eoc 2/yolo mouth detection/yawn train/labels",
        "output": "C:/Users/vani1/OneDrive/Desktop/eoc 2/archive/train/open_mouth"
    },
    "no_yawn": {
        "images": "C:/Users/vani1/OneDrive/Desktop/eoc 2/yolo mouth detection/no_yawn train/images",
        "labels": "C:/Users/vani1/OneDrive/Desktop/eoc 2/yolo mouth detection/no_yawn train/labels",
        "output": "C:/Users/vani1/OneDrive/Desktop/eoc 2/archive/train\closed_mouth"
    }
}

# Create output directories
for category in datasets:
    os.makedirs(datasets[category]["output"], exist_ok=True)

# Loop through both datasets
for category, paths in datasets.items():
    image_dir = paths["images"]
    label_dir = paths["labels"]
    output_dir = paths["output"]

    for label_file in os.listdir(label_dir):
        if not label_file.endswith('.txt'):
            continue

        label_path = os.path.join(label_dir, label_file)
        image_path = os.path.join(image_dir, label_file.replace('.txt', '.jpg'))

        if not os.path.exists(image_path):
            continue

        # Load image
        img = cv2.imread(image_path)
        h, w, _ = img.shape

        # Read YOLO label file
        with open(label_path, 'r') as f:
            for i, line in enumerate(f):
                class_id, x_center, y_center, box_w, box_h = map(float, line.strip().split())

                # Convert to pixel coordinates
                x1 = int((x_center - box_w / 2) * w)
                y1 = int((y_center - box_h / 2) * h)
                x2 = int((x_center + box_w / 2) * w)
                y2 = int((y_center + box_h / 2) * h)

                # Crop and save
                cropped = img[y1:y2, x1:x2]
                if cropped.size == 0:
                    continue

                output_name = f"{label_file.replace('.txt', '')}_{i}.jpg"
                cv2.imwrite(os.path.join(output_dir, output_name), cropped)

print(" All mouth crops saved successfully!")
