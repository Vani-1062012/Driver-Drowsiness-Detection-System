

!pip install ultralytics

from google.colab import files
uploaded = files.upload()

!ls /content/datasets/yolo_dataset/valid/images

import zipfile
import os

zip_path = "driver_face.v1i.yolov8.zip"  

with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall("yolo_dataset")

from ultralytics import YOLO

# Load a YOLOv8 base model
model = YOLO("yolov8n.pt")  


# Train your model
model.train(
    data="/content/yolo_dataset/data.yaml",  
    epochs=50,                           
    imgsz=640,
    batch=16,                            
    device=0                             
)