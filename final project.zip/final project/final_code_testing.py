import sys
import cv2
import time
import queue
import numpy as np
import threading
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QHBoxLayout, QWidget
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt
from ultralytics import YOLO
from tensorflow.keras.models import load_model

class DrowsinessDetector(QMainWindow):
    def __init__(self):
        super().__init__()

        # State
        self.eye_state = ''
        self.mouth_state = ''
        self.alert_text = ''
        self.blinks = 0
        self.microsleeps = 0
        self.yawns = 0
        self.yawn_duration = 0
        self.eye_closed = False
        self.yawn_in_progress = False

        # UI setup
        self.setWindowTitle("Drowsiness Detection")
        self.setGeometry(100, 100, 900, 600)
        self.setStyleSheet("background-color: white;")
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)
        self.layout = QHBoxLayout(self.central_widget)

        self.video_label = QLabel()
        self.video_label.setFixedSize(640, 480)
        self.layout.addWidget(self.video_label)

        self.info_label = QLabel()
        self.info_label.setStyleSheet("border: 1px solid black; padding: 10px; background-color: white;")
        self.layout.addWidget(self.info_label)

        self.update_info()

        # Load models
        self.yolo_model = YOLO("C:/Users/vani1/OneDrive/Desktop/eoc 2/yolo_final_training/best.pt")  # 3-class model: face, eyes, mouth
        self.eye_model = load_model("eye_classification_model.keras")
        self.mouth_model = load_model("mouth_classification_model.keras")

        # Webcam + threading
        self.cap = cv2.VideoCapture(0)
        time.sleep(1)
        self.frame_queue = queue.Queue(maxsize=2)
        self.stop_event = threading.Event()
        threading.Thread(target=self.capture_frames).start()
        threading.Thread(target=self.process_frames).start()

    def capture_frames(self):
        while not self.stop_event.is_set():
            ret, frame = self.cap.read()
            if ret and self.frame_queue.qsize() < 2:
                self.frame_queue.put(frame)

    def preprocess_for_cnn(self, img, size=(64, 64)):
        img = cv2.resize(img, size)
        img = img / 255.0
        return np.expand_dims(img, axis=0)

    def predict_eye_state(self, eye_roi):
        pred = self.eye_model.predict(self.preprocess_for_cnn(eye_roi), verbose=0)[0]
        return "Closed" if np.argmax(pred) == 0 else "Open"

    def predict_mouth_state(self, mouth_roi):
        pred = self.mouth_model.predict(self.preprocess_for_cnn(mouth_roi), verbose=0)[0]
        return "Yawn" if np.argmax(pred) == 1 else "No Yawn"

    def update_info(self):
        info = (
            f"<h2 style='color: green;'>Drowsiness Detection</h2>"
            f"{self.alert_text}"
            f"<p><b>👁️ Eye State:</b> {self.eye_state}</p>"
            f"<p><b>💤 Microsleep:</b> {round(self.microsleeps, 2)} sec</p>"
            f"<p><b>😮 Yawns:</b> {self.yawns}</p>"
            f"<p><b>⏳ Yawn Duration:</b> {round(self.yawn_duration, 2)} sec</p>"
        )
        self.info_label.setText(info)


    def process_frames(self):
        while not self.stop_event.is_set():
            try:
                frame = self.frame_queue.get(timeout=1)
                results = self.yolo_model.predict(frame, conf=0.3, verbose=False)[0]
                detections = results.boxes

                eye_roi = mouth_roi = None
                self.eye_state = "Unknown"
                self.mouth_state = "Unknown"

                for box in detections:
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    class_id = int(box.cls[0])
                    label = self.yolo_model.model.names[class_id]

                    crop = frame[y1:y2, x1:x2]
                    if crop.size == 0:
                        continue  # skip invalid crops

                    if label.lower() == "eyes":
                        eye_roi = crop
                    elif label.lower() == "mouth":
                        mouth_roi = crop

                # --- Eye detection & microsleep logic ---
                if eye_roi is not None:
                    try:
                        processed_eye = self.preprocess_for_cnn(eye_roi)
                        pred = self.eye_model.predict(processed_eye, verbose=0)[0]
                        self.eye_state = "Closed" if np.argmax(pred) == 0 else "Open"
                    except:
                        self.eye_state = "Unknown"

                    if self.eye_state == "Closed":
                        self.microsleeps += 45 / 1000
                    else:
                        self.microsleeps = 0  # reset if eyes are open

                # --- Mouth detection & yawn logic ---
                if mouth_roi is not None:
                    try:
                        processed_mouth = self.preprocess_for_cnn(mouth_roi)
                        pred = self.mouth_model.predict(processed_mouth, verbose=0)[0]
                        self.mouth_state = "Yawn" if np.argmax(pred) == 1 else "No Yawn"
                    except:
                        self.mouth_state = "Unknown"

                    if self.mouth_state == "Yawn":
                        if not self.yawn_in_progress:
                            self.yawn_in_progress = True
                            self.yawns += 1
                        self.yawn_duration += 45 / 1000
                    else:
                        self.yawn_in_progress = False
                        self.yawn_duration = 0

                # --- Dynamic Alert Logic ---
                if self.microsleeps > 4 and self.yawns >= 3:
                    self.alert_text = "<p style='color: red;'>🚨 Driver is SLEEPING!</p>"
                elif self.microsleeps > 2 or self.yawns >= 2:
                    self.alert_text = "<p style='color: orange;'>⚠️ Driver Might Feel Drowsy</p>"
                else:
                    self.alert_text = "<p style='color: green;'>✅ Driver is Awake</p>"

                self.update_info()
                self.display_frame(frame)

            except queue.Empty:
                continue

    def display_frame(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        qt_img = QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0], QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(qt_img))

    def closeEvent(self, event):
        self.stop_event.set()
        self.cap.release()
        super().closeEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = DrowsinessDetector()
    win.show()
    sys.exit(app.exec_())
